docker build -t nancyhussein/assign1 .

docker run -it --name bigdata nancyhussein/assign1

touch load.py eda.py dpre.py model.py vis.py

python3 load.py Popular_Spotify_Songs.csv


Set-ExcutionPolicy RemoteSigned
.\final.ps1



docker image nancyhussein/assign1