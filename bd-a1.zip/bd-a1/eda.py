import pandas as pd

# Load the data
df = pd.read_csv("Popular_Spotify_Songs.csv", encoding='latin1')

# Remove non-numeric columns
numeric_df = df.select_dtypes(include=['number'])

# Insight 1: Summary statistics
summary_stats = numeric_df.describe()
summary_stats.to_csv("eda-in-1.txt")

# Insight 2: Correlation matrix
corr_matrix = numeric_df.corr()
corr_matrix.to_csv("eda-in-2.txt")

# Insight 3: Data distribution
# Replace 'actual_column_name' with the correct column name
column_name = 'track_name'

# Check if the column exists in the DataFrame
if column_name in df.columns:
    # Analyze data distribution for the specified column
    top_values = df[column_name].value_counts().head(5)
    top_values.to_csv("eda-in-3.txt", header=True)
else:
    print(f"Column '{column_name}' not found in the DataFrame.")
    


